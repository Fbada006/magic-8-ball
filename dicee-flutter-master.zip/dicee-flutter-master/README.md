## What this project shows
- Using Flutter stateless widgets .
- Using Flutter stateful widgets.
- Using onClick listeners for buttons.
- Using setState to mark the widget tree as dirty and requiring update on the next render.
- Using expanded widget to make widgets adapt to screen dimensions.

## I love Flutter